<?php
    require_once 'conexionBD.php';

    function getEquipos(): array
    {
        $equipos = array();
        $pdo = getConexion();
        $consulta = "select nombre from equipos";

        if ($resultado = $pdo->query($consulta))
        {

            /* obtener el array de objetos */
            while ($equipo = $resultado->fetch(PDO::FETCH_OBJ))
            {
                $equipos[] = $equipo->nombre;
            }
            unset($resultado);
        } 
        unset($pdo);
        return $equipos;
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Equipos</title>
        <link rel="stylesheet" media="screen" href="css/estilo.css" >
    </head>
    <body>
        <h1>Equipos de la NBA</h1>
        <ul>
            <?php
                require_once 'Clases\funcionesBD.php';

                $equipos = getEquipos();
                foreach ($equipos as $equipo) 
                {
                    echo "<li>$equipo</li>";
                }
            ?>
        </ul>		
    </body>
</html>